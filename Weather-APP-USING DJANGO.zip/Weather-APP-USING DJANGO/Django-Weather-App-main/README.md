Django-Weather-App
1. Download files from repository
2. Install requests library using : 
    pip install requests
3. Then run these two command on cmd to access database:
    1: python manage.py makemigrations
    2: python manage.py migrate
4. Then run the project by typing this command in cmd : 
    python manage.py runserver
